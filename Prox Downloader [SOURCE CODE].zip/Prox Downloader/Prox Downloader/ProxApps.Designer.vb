﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProxApps
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ProxApps))
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.linkTextProx = New System.Windows.Forms.TextBox()
        Me.browseTextProx = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.browserButtons = New System.Windows.Forms.Button()
        Me.downloadButtons = New System.Windows.Forms.Button()
        Me.progressDownload = New System.Windows.Forms.ProgressBar()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.headerProx = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.fb = New System.Windows.Forms.PictureBox()
        Me.gt = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.logoProx = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.contactProx = New System.Windows.Forms.Panel()
        Me.headerProx.SuspendLayout()
        CType(Me.fb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.logoProx, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Label3.Location = New System.Drawing.Point(20, 121)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(365, 21)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Download your Files with URL and Custom Browse."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Label4.Location = New System.Drawing.Point(20, 161)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 17)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Link :"
        '
        'linkTextProx
        '
        Me.linkTextProx.Location = New System.Drawing.Point(84, 161)
        Me.linkTextProx.Name = "linkTextProx"
        Me.linkTextProx.Size = New System.Drawing.Size(411, 20)
        Me.linkTextProx.TabIndex = 7
        Me.linkTextProx.Text = "http://yourlinkdownload.com/files"
        '
        'browseTextProx
        '
        Me.browseTextProx.Location = New System.Drawing.Point(84, 190)
        Me.browseTextProx.Name = "browseTextProx"
        Me.browseTextProx.ReadOnly = True
        Me.browseTextProx.Size = New System.Drawing.Size(411, 20)
        Me.browseTextProx.TabIndex = 9
        Me.browseTextProx.Text = "C:\Users\HandSome\Downloads\mydownload.exe"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Label5.Location = New System.Drawing.Point(21, 190)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 17)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Browse :"
        '
        'browserButtons
        '
        Me.browserButtons.Location = New System.Drawing.Point(501, 188)
        Me.browserButtons.Name = "browserButtons"
        Me.browserButtons.Size = New System.Drawing.Size(88, 23)
        Me.browserButtons.TabIndex = 10
        Me.browserButtons.Text = "Browse.."
        Me.browserButtons.UseVisualStyleBackColor = True
        '
        'downloadButtons
        '
        Me.downloadButtons.Location = New System.Drawing.Point(501, 258)
        Me.downloadButtons.Name = "downloadButtons"
        Me.downloadButtons.Size = New System.Drawing.Size(88, 37)
        Me.downloadButtons.TabIndex = 11
        Me.downloadButtons.Text = "Download"
        Me.downloadButtons.UseVisualStyleBackColor = True
        '
        'progressDownload
        '
        Me.progressDownload.Location = New System.Drawing.Point(23, 258)
        Me.progressDownload.Name = "progressDownload"
        Me.progressDownload.Size = New System.Drawing.Size(472, 37)
        Me.progressDownload.TabIndex = 12
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(20, 238)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(131, 17)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Loading Download ..."
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(545, 129)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(38, 13)
        Me.LinkLabel1.TabIndex = 14
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Help ?"
        '
        'headerProx
        '
        Me.headerProx.BackColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.headerProx.BackgroundImage = Global.Prox_Downloader.My.Resources.Resources.bg
        Me.headerProx.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.headerProx.Controls.Add(Me.Label7)
        Me.headerProx.Controls.Add(Me.fb)
        Me.headerProx.Controls.Add(Me.gt)
        Me.headerProx.Controls.Add(Me.Label2)
        Me.headerProx.Controls.Add(Me.logoProx)
        Me.headerProx.Controls.Add(Me.Label1)
        Me.headerProx.Controls.Add(Me.contactProx)
        Me.headerProx.Dock = System.Windows.Forms.DockStyle.Top
        Me.headerProx.Location = New System.Drawing.Point(0, 0)
        Me.headerProx.Name = "headerProx"
        Me.headerProx.Size = New System.Drawing.Size(608, 104)
        Me.headerProx.TabIndex = 0
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(430, 85)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(109, 13)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "Author by Pku.LNX#"
        '
        'fb
        '
        Me.fb.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.fb.Cursor = System.Windows.Forms.Cursors.Hand
        Me.fb.Image = CType(resources.GetObject("fb.Image"), System.Drawing.Image)
        Me.fb.Location = New System.Drawing.Point(557, 57)
        Me.fb.Name = "fb"
        Me.fb.Size = New System.Drawing.Size(36, 35)
        Me.fb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.fb.TabIndex = 4
        Me.fb.TabStop = False
        '
        'gt
        '
        Me.gt.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.gt.Cursor = System.Windows.Forms.Cursors.Hand
        Me.gt.Image = Global.Prox_Downloader.My.Resources.Resources.github
        Me.gt.Location = New System.Drawing.Point(556, 14)
        Me.gt.Name = "gt"
        Me.gt.Size = New System.Drawing.Size(38, 35)
        Me.gt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.gt.TabIndex = 3
        Me.gt.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(102, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(225, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "A Simple Files Downloader for Desktop"
        '
        'logoProx
        '
        Me.logoProx.BackColor = System.Drawing.Color.Transparent
        Me.logoProx.Image = Global.Prox_Downloader.My.Resources.Resources.P
        Me.logoProx.Location = New System.Drawing.Point(41, 26)
        Me.logoProx.Name = "logoProx"
        Me.logoProx.Size = New System.Drawing.Size(50, 57)
        Me.logoProx.TabIndex = 0
        Me.logoProx.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label1.Location = New System.Drawing.Point(102, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(216, 21)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Welcome to Prox Downloader"
        '
        'contactProx
        '
        Me.contactProx.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.contactProx.Dock = System.Windows.Forms.DockStyle.Right
        Me.contactProx.Location = New System.Drawing.Point(543, 0)
        Me.contactProx.Name = "contactProx"
        Me.contactProx.Size = New System.Drawing.Size(65, 104)
        Me.contactProx.TabIndex = 1
        '
        'ProxApps
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(608, 308)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.progressDownload)
        Me.Controls.Add(Me.downloadButtons)
        Me.Controls.Add(Me.browserButtons)
        Me.Controls.Add(Me.browseTextProx)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.linkTextProx)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.headerProx)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "ProxApps"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Prox"
        Me.headerProx.ResumeLayout(False)
        Me.headerProx.PerformLayout()
        CType(Me.fb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.logoProx, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents headerProx As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents logoProx As PictureBox
    Friend WithEvents gt As PictureBox
    Friend WithEvents fb As PictureBox
    Friend WithEvents contactProx As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents linkTextProx As TextBox
    Friend WithEvents browseTextProx As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents browserButtons As Button
    Friend WithEvents downloadButtons As Button
    Friend WithEvents progressDownload As ProgressBar
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents LinkLabel1 As LinkLabel
End Class
