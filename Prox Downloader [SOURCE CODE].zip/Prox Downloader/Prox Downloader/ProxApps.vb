﻿Imports System.Net
Public Class ProxApps
    Private Sub contactProx_MouseHover(sender As Object, e As EventArgs) Handles contactProx.MouseHover
        contactProx.BackColor = Color.FromArgb(85, 85, 85)
        gt.BackColor = Color.FromArgb(85, 85, 85)
        fb.BackColor = Color.FromArgb(85, 85, 85)
    End Sub

    Private Sub contactProx_MouseLeave(sender As Object, e As EventArgs) Handles contactProx.MouseLeave
        contactProx.BackColor = Color.FromArgb(51, 51, 51)
        gt.BackColor = Color.FromArgb(51, 51, 51)
        fb.BackColor = Color.FromArgb(51, 51, 51)
    End Sub
    Public WithEvents download As WebClient
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        logoProx.Focus()
        Me.BringToFront()

        Try
            My.Computer.Network.Ping("google.com")
            MsgBox("Internet Connection was Online !", 0 + 64, "Welcome")
        Catch ex As Exception
            MsgBox("There is No Internet Connection !" & vbNewLine & "Click OK for skip this alert.", 0 + 16, "Oopss..")
        End Try
    End Sub

    Private Sub browserButtons_Click(sender As Object, e As EventArgs) Handles browserButtons.Click
        SaveFileDialog1.Filter = ".EXE Files|*.exe|.ZIP Files|*.zip|.RAR Files|*.rar|.JPG Files|*.jpg|.JPEG Files|*.jpeg|.PNG Files|*.png|.GIF Files|*.gif|.BMP Files|*.bmp|.MP4 Files|*.mp4|.ISO Files|*.iso|.MP3 Files|*.mp3|.MKV Files|*.mkv|.SRT Files|*.srt"
        SaveFileDialog1.ShowDialog()
        browseTextProx.Text = SaveFileDialog1.FileName
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Help.Show()
        Me.WindowState = WindowState.Minimized
    End Sub

    Private Sub downloadButtons_Click(sender As Object, e As EventArgs) Handles downloadButtons.Click
        download = New WebClient
        download.DownloadFileAsync(New Uri(linkTextProx.Text), browseTextProx.Text)
        Try
            My.Computer.Network.Ping("google.com")
            MsgBox("Please waiting Downloading until Finishing ..", 0 + 64, "Warning")
        Catch ex As Exception
            MsgBox("There is No Internet Connection !" & vbNewLine & "Application will quick exit now.", 0 + 16, "Oopss..")
            End
        End Try
    End Sub

    Private Sub download_DownloadProgressChanged(sender As Object, e As DownloadProgressChangedEventArgs) Handles download.DownloadProgressChanged
        progressDownload.Value = e.ProgressPercentage
        If progressDownload.Value = progressDownload.Maximum Then

            MsgBox("Download Sucessfully !", 0 + 64, "Prox Downloader")
        End If
    End Sub

    Private Sub gt_Click(sender As Object, e As EventArgs) Handles gt.Click
        Process.Start("https://github.com/lnxcrew")
    End Sub

    Private Sub fb_Click(sender As Object, e As EventArgs) Handles fb.Click
        MsgBox("Contact Me for More information about this Application", 0 + 64, "Author")
        Process.Start("https://www.facebook.com/adi.wj0")
    End Sub
End Class
