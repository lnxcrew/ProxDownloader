﻿Public Class EnglishHelp
    Private Sub English_Click(sender As Object, e As EventArgs) Handles English.Click
        Me.Hide()
        ProxApps.WindowState = WindowState.Normal
    End Sub
End Class