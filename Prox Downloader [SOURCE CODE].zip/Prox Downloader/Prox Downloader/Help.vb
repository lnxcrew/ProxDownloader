﻿Public Class Help
    Private Sub English_Click(sender As Object, e As EventArgs) Handles English.Click
        EnglishHelp.Show()
        Me.Hide()
    End Sub

    Private Sub Indonesia_Click(sender As Object, e As EventArgs) Handles Indonesia.Click
        IndonesiaHelp.Show()
        Me.Hide()
    End Sub
End Class