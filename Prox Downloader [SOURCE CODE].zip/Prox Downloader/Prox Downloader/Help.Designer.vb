﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Help
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Help))
        Me.English = New System.Windows.Forms.Button()
        Me.Indonesia = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'English
        '
        Me.English.Location = New System.Drawing.Point(83, 77)
        Me.English.Name = "English"
        Me.English.Size = New System.Drawing.Size(155, 76)
        Me.English.TabIndex = 0
        Me.English.Text = "English"
        Me.English.UseVisualStyleBackColor = True
        '
        'Indonesia
        '
        Me.Indonesia.Location = New System.Drawing.Point(258, 77)
        Me.Indonesia.Name = "Indonesia"
        Me.Indonesia.Size = New System.Drawing.Size(155, 76)
        Me.Indonesia.TabIndex = 1
        Me.Indonesia.Text = "Indonesia"
        Me.Indonesia.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Label3.Location = New System.Drawing.Point(94, 43)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(308, 21)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Choose your Language for Help Download."
        '
        'Help
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(497, 196)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Indonesia)
        Me.Controls.Add(Me.English)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Help"
        Me.ShowInTaskbar = False
        Me.Text = "Help"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents English As Button
    Friend WithEvents Indonesia As Button
    Friend WithEvents Label3 As Label
End Class
